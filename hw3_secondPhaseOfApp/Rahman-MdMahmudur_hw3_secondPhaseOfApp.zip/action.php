
<?php

//Code source : https://stackoverflow.com/questions/35443812/how-to-save-string-entered-in-html-form-to-text-file
 $path = 'data.txt';

$fh = fopen($path,"a+");
$string = $_POST['location'].' , '.$_POST['cntr'].' , '.$_POST['dsr_plc'].' , '.$_POST['family_from'].' , '.$_POST['fav_music'].' , '.$_POST['place_birth'].' , '.$_POST['live_now'].' , '.$_POST['like2live'].' , '.$_POST['sig_other_born'].' , '.$_POST['inv_my'].' , '.$_POST['inv_family'].' , '.$_POST['fav_sport'].' , '.$_POST['int_other']."\n";
fwrite($fh,$string); // Write information to the file
fclose($fh); // Close the file
echo 'Information Submitted Successfuly';
 
?>